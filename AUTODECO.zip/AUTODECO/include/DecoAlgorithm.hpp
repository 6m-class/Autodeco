#pragma once

#include <Geode/Geode.hpp>
#include <vector>
#include <map>
#include <set>

using namespace geode::prelude;

// ============================================================================
// ID декоративных объектов GD 2.2
// TODO: сверить точные ID по справочнику объектов GD 2.2081
// Если ID неверный — заменить на корректные из Node IDs / object IDs
// ============================================================================
namespace DecoIDs {
    // Треугольные объекты для шпилей (используем треугольники из decoration)
    constexpr int SPIKE_LARGE_ID     = 3979;  // Большой треугольник (spike decoration)
    constexpr int SPIKE_MEDIUM_ID    = 3981;  // Средний треугольник
    constexpr int SPIKE_SMALL_ID     = 3983;  // Малый треугольник

    // Квадратные "узлы-микросхемы"
    constexpr int SQUARE_NODE_OUTER  = 4097;  // Внешний квадрат узла
    constexpr int SQUARE_NODE_INNER  = 4099;  // Внутренний квадрат узла

    // Линии-дорожки (тонкие)
    constexpr int LINE_V_THIN        = 4113;  // Вертикальная тонкая линия
    constexpr int LINE_H_THIN        = 4115;  // Горизонтальная тонкая линия
    constexpr int LINE_V_GLOW        = 4117;  // Вертикальная glow-линия
    constexpr int LINE_H_GLOW        = 4119;  // Горизонтальная glow-линия

    // Блоки-окантовка (edge trim)
    constexpr int EDGE_TRIM_V        = 4131;  // Вертикальная окантовка
    constexpr int EDGE_TRIM_H        = 4133;  // Горизонтальная окантовка
    constexpr int EDGE_CORNER        = 4135;  // Угловой элемент

    // Дополнительные декоративные элементы
    constexpr int GLOW_ORB_SMALL     = 4151;  // Маленький светящийся шар
    constexpr int GLOW_ORB_MEDIUM    = 4153;  // Средний светящийся шар
}

// ============================================================================
// Цветовые каналы (Color Channel IDs)
// Используем каналы 20-25, чтобы не конфликтовать с логикой игрока
// Ch20 = magenta, Ch21 = purple, Ch22 = orange-yellow, Ch23 = cyan, Ch24 = background
// ============================================================================
namespace ColorChannels {
    constexpr int CH20_MAGENTA  = 20;  // #FF00FF — основной glow
    constexpr int CH21_PURPLE   = 21;  // #8A2BE2 — фиолетовый
    constexpr int CH22_ORANGE   = 22;  // #FFAA00 — оранжево-жёлтый glow
    constexpr int CH23_CYAN     = 23;  // #00FFFF — cyan glow
    constexpr int CH24_BG_DARK  = 24;  // Тёмный сине-чёрный фон
    constexpr int CH25_ACCENT   = 25;  // Дополнительный акцентный цвет
}

// ============================================================================
// Структуры данных
// ============================================================================

// Ячейка occupancy-сетки
struct GridCell {
    int x;                          // Координата X ячейки (в единицах сетки)
    std::set<int> occupiedY;        // Набор занятых Y-позиций (в единицах сетки)

    bool isOccupied(int y) const { return occupiedY.count(y) > 0; }
    void occupy(int y) { occupiedY.insert(y); }
    int maxY() const { return occupiedY.empty() ? 0 : *occupiedY.rbegin(); }
    int minY() const { return occupiedY.empty() ? 0 : *occupiedY.begin(); }
};

// Описание одной башни (кластера)
struct TowerCluster {
    int id;                             // Уникальный ID башни (для Group ID)
    std::vector<int> columns;           // Столбцы X (в единицах сетки), отсортированные
    std::map<int, GridCell> cells;      // Ячейки по X

    // Геометрические характеристики
    int topY = 0;                       // Максимальная Y (вершина башни)
    int bottomY = 0;                    // Минимальная Y (основание)
    int leftX = 0;                      // Левый край
    int rightX = 0;                     // Правый край
    int colorIndex = 0;                 // Индекс цвета для чередования (0-3)

    // Точки спавна декора
    struct SpawnPoint {
        CCPoint worldPos;               // Мировая позиция
        int type;                       // Тип: 0=большой шпиль, 1=малый шпиль,
                                        //       2=узел-квадрат, 3=линия-дорожка,
                                        //       4=окантовка, 5=glow orb
        int colorChannel;               // Цветовой канал
    };
    std::vector<SpawnPoint> spawnPoints;
};

// ============================================================================
// Основной класс алгоритма
// ============================================================================
class DecoAlgorithm {
public:
    // Главный метод: декорировать выделенные объекты
    // Возвращает количество добавленных объектов
    static int decorateSelection(EditorUI* editor, CCArray* selectedObjects);

private:
    // Шаг 1: Фильтрация солид-блоков
    static std::vector<GameObject*> filterSolidBlocks(CCArray* objects);

    // Шаг 2: Построение occupancy-сетки
    static std::map<int, GridCell> buildOccupancyGrid(
        const std::vector<GameObject*>& blocks, int gridSize
    );

    // Шаг 3: Кластеризация в башни
    static std::vector<TowerCluster> clusterTowers(
        const std::map<int, GridCell>& grid, int gridSize
    );

    // Шаг 4: Анализ геометрии башни и генерация точек спавна
    static void analyzeTower(TowerCluster& tower, int gridSize, int spireHeight);

    // Шаг 5: Спавн декоративных объектов
    static int spawnDecorations(
        EditorUI* editor,
        const TowerCluster& tower,
        int startGroupID,
        bool enableGlow
    );

    // Шаг 6: Настройка цветовых каналов уровня
    static void setupColorChannels(EditorUI* editor);

    // Вспомогательные методы
    static CCPoint gridToWorld(int gridX, int gridY, int gridSize);
    static int worldToGrid(float worldCoord, int gridSize);
    static int getNextGroupID(EditorUI* editor);
    static bool isChannelFree(EditorUI* editor, int channelID);

    // Создание одного декоративного объекта
    static GameObject* createDecoObject(
        EditorUI* editor,
        int objectID,
        CCPoint position,
        int colorChannel,
        bool glow,
        int groupID
    );
};
