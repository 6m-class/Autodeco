#include "DecoAlgorithm.hpp"
#include <algorithm>
#include <random>
#include <queue>

using namespace geode::prelude;

// ============================================================================
// Вспомогательные методы
// ============================================================================

CCPoint DecoAlgorithm::gridToWorld(int gridX, int gridY, int gridSize) {
    return CCPoint(gridX * gridSize, gridY * gridSize);
}

int DecoAlgorithm::worldToGrid(float worldCoord, int gridSize) {
    return static_cast<int>(std::round(worldCoord / gridSize));
}

int DecoAlgorithm::getNextGroupID(EditorUI* editor) {
    // Получаем максимальный Group ID из уровня и добавляем 1
    // В GD 2.2 Group IDs хранятся в LevelSettingsObject
    auto levelLayer = editor->getParent();
    if (!levelLayer) return 1;

    // Упрощённая логика: начинаем с 1000, чтобы не конфликтовать с существующими
    // TODO: в реальной реализации нужно сканировать все объекты уровня
    static int nextGroupID = 1000;
    return nextGroupID++;
}

bool DecoAlgorithm::isChannelFree(EditorUI* editor, int channelID) {
    // Проверяем, не занят ли цветовой канал игроком
    // В GD 2.2 цветовые каналы хранятся в ColorActionStore
    // Мы используем каналы 20-25, которые обычно свободны
    return channelID >= 20 && channelID <= 25;
}

// ============================================================================
// Шаг 1: Фильтрация солид-блоков
// ============================================================================

std::vector<GameObject*> DecoAlgorithm::filterSolidBlocks(CCArray* objects) {
    std::vector<GameObject*> solids;

    if (!objects) return solids;

    CCARRAY_FOREACH_Basetype(objects, obj, GameObject*) {
        if (!obj) continue;

        // Проверяем, является ли объект солид-блоком
        // В GD 2.2 солид-блоки имеют определённые свойства
        // m_objectType == GameObjectType::Solid или m_isSolid == true
        // Упрощённая проверка: объект имеет m_objectID в диапазоне солид-блоков

        int objID = obj->m_objectID;

        // Солид-блоки: обычные блоки (1-99), шипы (100-199), и т.д.
        // Точный диапазон зависит от версии GD
        // Здесь проверяем, что объект не является декорацией (ID > 1000)
        if (objID > 0 && objID < 1000) {
            solids.push_back(obj);
        }
    }

    return solids;
}

// ============================================================================
// Шаг 2: Построение occupancy-сетки
// ============================================================================

std::map<int, GridCell> DecoAlgorithm::buildOccupancyGrid(
    const std::vector<GameObject*>& blocks, int gridSize
) {
    std::map<int, GridCell> grid;

    for (auto* block : blocks) {
        if (!block) continue;

        CCPoint pos = block->getPosition();
        int gridX = worldToGrid(pos.x, gridSize);
        int gridY = worldToGrid(pos.y, gridSize);

        // Создаём ячейку, если её нет
        if (grid.find(gridX) == grid.end()) {
            GridCell cell;
            cell.x = gridX;
            grid[gridX] = cell;
        }

        // Помечаем ячейку как занятую
        grid[gridX].occupy(gridY);
    }

    return grid;
}

// ============================================================================
// Шаг 3: Кластеризация в башни
// ============================================================================

std::vector<TowerCluster> DecoAlgorithm::clusterTowers(
    const std::map<int, GridCell>& grid, int gridSize
) {
    std::vector<TowerCluster> towers;
    std::set<int> visited;

    // Для каждой колонки пытаемся построить кластер
    for (const auto& [x, cell] : grid) {
        if (visited.count(x) > 0) continue;

        // BFS по соседним колонкам
        TowerCluster tower;
        tower.id = static_cast<int>(towers.size());
        std::queue<int> queue;
        queue.push(x);
        visited.insert(x);

        while (!queue.empty()) {
            int currentX = queue.front();
            queue.pop();

            // Добавляем текущую колонку в башню
            tower.columns.push_back(currentX);
            tower.cells[currentX] = grid.at(currentX);

            // Проверяем соседей (X-1 и X+1)
            for (int dx : {-1, 1}) {
                int neighborX = currentX + dx;

                if (grid.find(neighborX) == grid.end()) continue;
                if (visited.count(neighborX) > 0) continue;

                // Проверяем пересечение по Y
                const auto& currentCell = grid.at(currentX);
                const auto& neighborCell = grid.at(neighborX);

                bool hasIntersection = false;
                for (int y : currentCell.occupiedY) {
                    if (neighborCell.isOccupied(y)) {
                        hasIntersection = true;
                        break;
                    }
                }

                if (hasIntersection) {
                    visited.insert(neighborX);
                    queue.push(neighborX);
                }
            }
        }

        // Сортируем колонки по X
        std::sort(tower.columns.begin(), tower.columns.end());

        towers.push_back(tower);
    }

    return towers;
}

// ============================================================================
// Шаг 4: Анализ геометрии башни
// ============================================================================

void DecoAlgorithm::analyzeTower(TowerCluster& tower, int gridSize, int spireHeight) {
    if (tower.columns.empty()) return;

    // Находим границы башни
    tower.leftX = tower.columns.front();
    tower.rightX = tower.columns.back();
    tower.topY = 0;
    tower.bottomY = INT_MAX;

    for (int x : tower.columns) {
        const auto& cell = tower.cells[x];
        tower.topY = std::max(tower.topY, cell.maxY());
        tower.bottomY = std::min(tower.bottomY, cell.minY());
    }

    // Генерируем точки спавна

    // 1. Большой шпиль на вершине (средняя колонка)
    int midCol = tower.columns[tower.columns.size() / 2];
    CCPoint spirePos = gridToWorld(midCol, tower.topY + 1, gridSize);
    spirePos.y += spireHeight / 2; // Смещаем вверх на половину высоты шпиля

    tower.spawnPoints.push_back({
        spirePos,
        0, // Тип: большой шпиль
        ColorChannels::CH20_MAGENTA
    });

    // 2. Малые шпили на ступенях (перепады высоты)
    for (size_t i = 0; i < tower.columns.size() - 1; i++) {
        int x1 = tower.columns[i];
        int x2 = tower.columns[i + 1];

        int y1 = tower.cells[x1].maxY();
        int y2 = tower.cells[x2].maxY();

        if (std::abs(y1 - y2) > 0) {
            // Есть ступенька
            int stepX = (y1 > y2) ? x1 : x2;
            int stepY = std::max(y1, y2);

            CCPoint stepPos = gridToWorld(stepX, stepY + 1, gridSize);
            stepPos.y += spireHeight / 4; // Малый шпиль

            tower.spawnPoints.push_back({
                stepPos,
                1, // Тип: малый шпиль
                ColorChannels::CH22_ORANGE
            });
        }
    }

    // 3. Узел-квадрат на фасаде (случайная колонка, середина по Y)
    int facadeCol = tower.columns[rand() % tower.columns.size()];
    int facadeY = (tower.topY + tower.bottomY) / 2;

    CCPoint nodePos = gridToWorld(facadeCol, facadeY, gridSize);

    tower.spawnPoints.push_back({
        nodePos,
        2, // Тип: узел-квадрат
        ColorChannels::CH23_CYAN
    });

    // 4. Линия-дорожка от узла вниз
    CCPoint lineStart = nodePos;
    lineStart.y -= gridSize * 2; // Начинаем ниже узла

    CCPoint lineEnd = gridToWorld(facadeCol, tower.bottomY, gridSize);

    // Создаём несколько сегментов линии
    int numSegments = (lineStart.y - lineEnd.y) / gridSize;
    for (int i = 0; i < numSegments; i++) {
        CCPoint segPos = lineStart;
        segPos.y -= i * gridSize;

        tower.spawnPoints.push_back({
            segPos,
            3, // Тип: линия-дорожка
            ColorChannels::CH20_MAGENTA
        });
    }

    // 5. Окантовка по краям башни
    // Левый край
    CCPoint leftEdge = gridToWorld(tower.leftX - 1, tower.topY, gridSize);
    tower.spawnPoints.push_back({
        leftEdge,
        4, // Тип: окантовка
        ColorChannels::CH21_PURPLE
    });

    // Правый край
    CCPoint rightEdge = gridToWorld(tower.rightX + 1, tower.topY, gridSize);
    tower.spawnPoints.push_back({
        rightEdge,
        4, // Тип: окантовка
        ColorChannels::CH21_PURPLE
    });
}

// ============================================================================
// Создание декоративного объекта
// ============================================================================

GameObject* DecoAlgorithm::createDecoObject(
    EditorUI* editor,
    int objectID,
    CCPoint position,
    int colorChannel,
    bool glow,
    int groupID
) {
    // Создаём объект через EditorUI
    // В GD 2.2 используется метод createObject или аналог
    auto* obj = editor->createObject(objectID, position, false);

    if (!obj) return nullptr;

    // Настраиваем цветовой канал
    // В GD 2.2 это делается через m_colorIdx или ColorAction
    obj->m_colorIdx = colorChannel;

    // Включаем glow если нужно
    if (glow) {
        obj->m_hasGlow = true;
    }

    // Назначаем Group ID
    // В GD 2.2 Group IDs хранятся в m_groups (std::vector<int>)
    obj->m_groups.push_back(groupID);

    return obj;
}

// ============================================================================
// Шаг 5: Спавн декоративных объектов
// ============================================================================

int DecoAlgorithm::spawnDecorations(
    EditorUI* editor,
    const TowerCluster& tower,
    int startGroupID,
    bool enableGlow
) {
    int objectsCreated = 0;

    for (const auto& spawn : tower.spawnPoints) {
        int objectID = 0;

        // Выбираем ID объекта по типу
        switch (spawn.type) {
            case 0: // Большой шпиль
                objectID = DecoIDs::SPIKE_LARGE_ID;
                break;
            case 1: // Малый шпиль
                objectID = DecoIDs::SPIKE_SMALL_ID;
                break;
            case 2: // Узел-квадрат
                objectID = DecoIDs::SQUARE_NODE_OUTER;
                break;
            case 3: // Линия-дорожка
                objectID = DecoIDs::LINE_V_GLOW;
                break;
            case 4: // Окантовка
                objectID = DecoIDs::EDGE_TRIM_V;
                break;
            default:
                continue;
        }

        auto* obj = createDecoObject(
            editor,
            objectID,
            spawn.worldPos,
            spawn.colorChannel,
            enableGlow,
            startGroupID
        );

        if (obj) {
            objectsCreated++;

            // Для узла-квадрата добавляем внутренний квадрат
            if (spawn.type == 2) {
                CCPoint innerPos = spawn.worldPos;
                auto* innerObj = createDecoObject(
                    editor,
                    DecoIDs::SQUARE_NODE_INNER,
                    innerPos,
                    ColorChannels::CH22_ORANGE,
                    enableGlow,
                    startGroupID
                );
                if (innerObj) objectsCreated++;
            }
        }
    }

    return objectsCreated;
}

// ============================================================================
// Шаг 6: Настройка цветовых каналов
// ============================================================================

void DecoAlgorithm::setupColorChannels(EditorUI* editor) {
    // Настраиваем цветовые каналы уровня (20-25)
    // В GD 2.2 это делается через LevelSettingsObject->m_colorChannels

    // Упрощённая реализация: создаём ColorAction для каждого канала
    // TODO: в реальной реализации нужно использовать API GD для настройки каналов

    log::info("[NeonDeco] Настройка цветовых каналов (20-25):");
    log::info("  Ch20 (Magenta): #FF00FF");
    log::info("  Ch21 (Purple): #8A2BE2");
    log::info("  Ch22 (Orange): #FFAA00");
    log::info("  Ch23 (Cyan): #00FFFF");
    log::info("  Ch24 (BG Dark): #0A0A2E (тёмный сине-чёрный)");
    log::info("  Ch25 (Accent): #FF69B4 (hot pink акцент)");
}

// ============================================================================
// Главный метод: декорирование выделения
// ============================================================================

int DecoAlgorithm::decorateSelection(EditorUI* editor, CCArray* selectedObjects) {
    if (!editor || !selectedObjects || selectedObjects->count() == 0) {
        return 0;
    }

    // Получаем настройки мода
    auto* mod = Mod::get();
    int gridSize = mod->getSettingValue<int64_t>("grid-size");
    int spireHeight = mod->getSettingValue<int64_t>("spire-height");
    bool enableGlow = mod->getSettingValue<bool>("enable-glow");

    log::info("[NeonDeco] Начало декорирования. Выделено объектов: {}", selectedObjects->count());

    // Шаг 1: Фильтрация солид-блоков
    auto solids = filterSolidBlocks(selectedObjects);
    log::info("[NeonDeco] Солид-блоков: {}", solids.size());

    if (solids.empty()) {
        log::warn("[NeonDeco] Не найдено солид-блоков для декорирования");
        return 0;
    }

    // Шаг 2: Построение occupancy-сетки
    auto grid = buildOccupancyGrid(solids, gridSize);
    log::info("[NeonDeco] Построена сетка. Колонок: {}", grid.size());

    // Шаг 3: Кластеризация в башни
    auto towers = clusterTowers(grid, gridSize);
    log::info("[NeonDeco] Найдено башен: {}", towers.size());

    if (towers.empty()) {
        log::warn("[NeonDeco] Не найдено башен для декорирования");
        return 0;
    }

    // Шаг 4: Анализ геометрии каждой башни
    for (auto& tower : towers) {
        analyzeTower(tower, gridSize, spireHeight);
    }

    // Шаг 5: Настройка цветовых каналов
    setupColorChannels(editor);

    // Шаг 6: Спавн декора для каждой башни
    int totalObjects = 0;
    int groupID = getNextGroupID(editor);

    for (auto& tower : towers) {
        // Чередование цветов: меняем colorIndex для каждой башни
        tower.colorIndex = tower.id % 4;

        // Корректируем цвета в spawnPoints на основе colorIndex
        for (auto& spawn : tower.spawnPoints) {
            // Простая схема чередования: сдвигаем каналы
            spawn.colorChannel = ((spawn.colorChannel - 1 + tower.colorIndex) % 4) + 1;
        }

        int objects = spawnDecorations(editor, tower, groupID, enableGlow);
        totalObjects += objects;

        groupID++; // Новый Group ID для следующей башни
    }

    log::info("[NeonDeco] Декорирование завершено. Добавлено объектов: {}", totalObjects);

    return totalObjects;
}
