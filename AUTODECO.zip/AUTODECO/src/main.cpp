#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include "DecoAlgorithm.hpp"

using namespace geode::prelude;

// ============================================================================
// Глобальные переменные для кнопки Deco
// ============================================================================
static CCMenuItemSpriteExtra* g_decoButton = nullptr;

// ============================================================================
// Хук EditorUI::init — добавление кнопки "Deco"
// ============================================================================

class $modify(MyEditorUI, EditorUI) {
    // Поля для хранения ссылки на кнопку
    bool m_decoButtonAdded = false;

    bool init(LevelEditorLayer* editorLayer) {
        // Вызываем оригинальный init
        if (!EditorUI::init(editorLayer)) {
            return false;
        }

        // Добавляем кнопку "Deco" после инициализации
        this->scheduleOnce(
            schedule_selector(MyEditorUI::addDecoButtonDelayed),
            0.1f // Задержка 0.1 секунды, чтобы UI полностью загрузился
        );

        log::info("[NeonDeco] EditorUI::init() перехвачен, кнопка будет добавлена");

        return true;
    }

    // Отложенное добавление кнопки (после полной загрузки UI)
    void addDecoButtonDelayed(float dt) {
        if (m_decoButtonAdded) return;

        // Создаём спрайт для кнопки
        // Используем встроенный спрайт GD (кнопка из editor UI)
        auto btnSprite = ButtonSprite::create(
            "Deco",          // Текст
            40,              // Ширина (автоматическая)
            true,            // Абсолютная ширина
            "bigFont.fnt",   // Шрифт
            "GJ_button_04.png", // Фон кнопки (фиолетовый)
            24.0f            // Высота
        );

        // Создаём интерактивную кнопку
        g_decoButton = CCMenuItemSpriteExtra::create(
            btnSprite,
            this,
            menu_selector(MyEditorUI::onDecoButton)
        );

        // Позиция кнопки: рядом с панелью инструментов
        // В GD 2.2 панель инструментов обычно слева
        // Размещаем кнопку в правом верхнем углу редактора
        g_decoButton->setPosition({CCDirector::get()->getWinSize().width - 60,
                                    CCDirector::get()->getWinSize().height - 40});
        g_decoButton->setID("neon-deco-button"_spr);
        g_decoButton->setScale(0.8f);

        // Добавляем кнопку на UI
        this->addChild(g_decoButton, 10);

        m_decoButtonAdded = true;

        log::info("[NeonDeco] Кнопка 'Deco' добавлена на EditorUI");

        // Первоначально скрываем кнопку (нет выделения)
        updateDecoButtonState();
    }

    // Обновление состояния кнопки (видимость/активность)
    void updateDecoButtonState() {
        if (!g_decoButton) return;

        // Проверяем, есть ли выделенные объекты
        bool hasSelection = false;

        // В GD 2.2 выделенные объекты хранятся в m_selectedObjects
        if (this->m_selectedObjects && this->m_selectedObjects->count() > 0) {
            hasSelection = true;
        }

        // Показываем/скрываем кнопку
        g_decoButton->setVisible(hasSelection);
        g_decoButton->setEnabled(hasSelection);
    }

    // Обработчик нажатия на кнопку "Deco"
    void onDecoButton(CCObject* sender) {
        log::info("[NeonDeco] Кнопка 'Deco' нажата!");

        // Проверяем наличие выделения
        if (!this->m_selectedObjects || this->m_selectedObjects->count() == 0) {
            // Показываем ошибку
            auto alert = FLAlertLayer::create(
                "Neon Cyber-Castle Deco",
                "Сначала выделите объекты для декорирования!\n\nИспользуйте Ctrl+A для выбора всех объектов.",
                "OK"
            );
            alert->show();
            return;
        }

        int selectedCount = this->m_selectedObjects->count();
        auto* mod = Mod::get();
        int warningLimit = mod->getSettingValue<int64_t>("max-objects-warning");

        // Проверка на большое количество объектов
        if (selectedCount > warningLimit) {
            // Показываем диалог подтверждения
            auto confirmDialog = FLAlertLayer::create(
                this,
                "Подтверждение",
                fmt::format(
                    "Выделено {} объектов.\n"
                    "Декорирование может занять время и создать много объектов.\n\n"
                    "Продолжить?",
                    selectedCount
                ),
                "Отмена",
                "Декорировать",
                400.0f
            );
            confirmDialog->setTag(1001);
            confirmDialog->show();
            return;
        }

        // Запускаем декорирование
        executeDecoration();
    }

    // Выполнение декорирования
    void executeDecoration() {
        if (!this->m_selectedObjects || this->m_selectedObjects->count() == 0) {
            return;
        }

        log::info("[NeonDeco] Запуск алгоритма декорирования...");

        // Сохраняем состояние для Undo
        // В GD 2.2 используется система UndoObject
        // Создаём группу UndoObject для всех добавленных объектов

        // Запускаем алгоритм
        int objectsCreated = DecoAlgorithm::decorateSelection(
            this,
            this->m_selectedObjects
        );

        log::info("[NeonDeco] Алгоритм завершён. Создано объектов: {}", objectsCreated);

        // Показываем уведомление
        if (objectsCreated > 0) {
            Notification::create(
                fmt::format("Добавлено {} декоративных объектов!", objectsCreated).c_str(),
                NotificationIconType::Success
            )->show();

            // Обновляем UI редактора
            this->updateCreateMenu();

            // Пересчитываем выделение (включаем новые объекты если нужно)
            // В GD 2.2 это может потребовать вызова определённых методов
        } else {
            Notification::create(
                "Не удалось создать декор. Проверьте выделение.",
                NotificationIconType::Error
            )->show();
        }
    }

    // Переопределяем update для отслеживания выделения
    void update(float dt) {
        EditorUI::update(dt);

        // Обновляем состояние кнопки каждые несколько кадров
        static float timer = 0.0f;
        timer += dt;
        if (timer > 0.1f) { // Каждые 0.1 секунды
            timer = 0.0f;
            updateDecoButtonState();
        }
    }

    // Обработчик FLAlertLayer (для диалога подтверждения)
    void FLAlert_Clicked(FLAlertLayer* alert, bool btn2) {
        if (alert->getTag() == 1001) {
            if (btn2) {
                // Пользователь нажал "Декорировать"
                log::info("[NeonDeco] Подтверждение получено, запуск декорирования");
                executeDecoration();
            } else {
                // Пользователь нажал "Отмена"
                log::info("[NeonDeco] Декорирование отменено пользователем");
            }
        }
    }
};

// ============================================================================
// Хук MenuLayer::init — логирование загрузки мода
// ============================================================================

class $modify(MyMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }

        log::info("[NeonDeco] Мод 'Neon Cyber-Castle Auto-Decorator' загружен!");
        log::info("[NeonDeco] Откройте Level Editor и выделите объекты для декорирования.");

        return true;
    }
};

// ============================================================================
// События загрузки/выгрузки мода
// ============================================================================

$on_mod(Loaded) {
    log::info("[NeonDeco] Мод инициализирован. Версия Geode: {}",
              Geode::getVersion().toVString());
}

$on_mod(Unloaded) {
    log::info("[NeonDeco] Мод выгружен.");
}
